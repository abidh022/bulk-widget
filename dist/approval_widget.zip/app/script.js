
// const searchpopup = document.getElementById('searchbtn');
// const search_popup = document.getElementById('search_popup');
// const close_PopupBtn = document.getElementById('close_PopupBtn');

// // Show the popup when the button is clicked
// searchpopup.addEventListener('click', () => {
//     search_popup.style.display = 'flex';
// });

// // Close the popup when the close button is clicked
// close_PopupBtn.addEventListener('click', () => {
//     search_popup.style.display = 'none';
// });

// // Close the popup if the user clicks outside of the popup content
// window.addEventListener('click', (event) => {
//     if (event.target === search_popup) {
//         search_popup.style.display = 'none';
//     }
// });

// // Event listener for the "Done" button
// document.getElementById('doneBtn').addEventListener('click', () => {
//     const selectedModule = document.getElementById('module').value;
//     filterRecordsByModule(selectedModule);  // Filter records based on selected module
//     search_popup.style.display = 'none';  // Close the popup after done
// });

// // Event listener for the "Cancel" button
// document.getElementById('cancelBtn').addEventListener('click', () => {
//     ZAGlobal.filteredRecords = ZAGlobal.allRecords;  // Reset to all records
//     ZAGlobal.reRenderTableBody();  // Re-render table with all records
//     search_popup.style.display = 'none';  // Close the popup after cancel
// });


// var ZAGlobal = {};
// var config = { type: "awaiting" }

// ZOHO.embeddedApp.on("PageLoad", function (data) {
//     if (data && data.Entity) {
//         console.log('from page load');
//         ZAGlobal.module = data.Entity;
//         ZOHO.CRM.API.getApprovalRecords(config)
//             .then(function (toBeApproved) {
//                 console.log('Fetched records:', toBeApproved);
//                 ZAGlobal.filteredRecordsTotal = toBeApproved.data.length;
//                 ZAGlobal.filteredRecords = toBeApproved.data;
//                 ZAGlobal.allRecords = [...toBeApproved.data]; 
//                 console.log('Filtered Records (All Records):', ZAGlobal.filteredRecords);
                
//                 if (ZAGlobal.filteredRecords.length === 0) {
//                     console.log('No records to render');
//                 } else {
//                     var tbody = '';
//                     ZAGlobal.filteredRecords.forEach(function (record) {
//                         tbody += `<tr><td><input type="checkbox" data-id="${record.entity.id}" data-module="${record.module}"></td><td>${record.entity.name}</td><td>${record.rule.name}</td><td>${record.entity.id}</td><td><div class="_status ${record.is_approved ? '_approved' : record.is_rejected ? '_rejected' : '_'}"></div></td></tr>`;
//                         console.log(record.module);
                        
//                     });

//                     $('._tbody').append(tbody);
//                 }
//             })
//             .catch(function (error) {
//                 console.log('Error fetching records:', error);
//             });
//         ZOHO.CRM.META.getModules().then(function (data) {
//             console.log(data);
//             if (data && Array.isArray(data.modules)) {
//                 data.modules.forEach((module, index) => {
//                     if (module.api_name) {
//                         // console.log(`Module ${index + 1}: ${module.api_name}`);
//                         function populateModules(modules) {
//                             const select = document.getElementById('module');

//                             select.innerHTML = '<option value="">Search in Specific Module</option>';
//                             modules.forEach(module => {
//                                 const option = document.createElement('option');
//                                 option.value = module.api_name;
//                                 option.textContent = module.api_name;
//                                 select.appendChild(option);
//                             });

//                             $('#module').select2({
//                                 placeholder: "Select a module",
//                                 allowClear: true
//                             });

//                             select.addEventListener('change', function () {
//                                 filterRecordsByModule(select.value); 
//                             });
//                         }

//                         // Call the function to populate the modules
//                         populateModules(data.modules);
//                     }
//                 });
//             } else {
//                 console.log("Modules array is not available.");
//             }
//         });


//     }
// });

// document.getElementById('resetTableBtn').addEventListener('click', () => {
//     ZAGlobal.filteredRecords = ZAGlobal.allRecords;  // Reset to all records
//     ZAGlobal.reRenderTableBody();  // Re-render table with all records
// });

// // Function to filter records based on selected module
// function filterRecordsByModule(selectedModule) {
//     if (selectedModule === "") {
//         // If no module is selected, display all records
//         ZAGlobal.filteredRecords = ZAGlobal.allRecords;
//     } else {
//         // Filter the records based on the selected module
//         ZAGlobal.filteredRecords = ZAGlobal.allRecords.filter(function (record) {
//             return record.module === selectedModule;
//         });
//     }

//     // Re-render the table with filtered records
//     ZAGlobal.reRenderTableBody();
// }

// ZAGlobal.selectAll = function () {
//     const headerCheckbox = document.querySelector('thead input[type="checkbox"]');
//     const rowCheckboxes = document.querySelectorAll('tbody input[type="checkbox"]');

//     headerCheckbox.addEventListener('change', () => {
//         rowCheckboxes.forEach(checkbox => {
//             checkbox.checked = headerCheckbox.checked;
//         });
//     });
// }

// // Re-render the table body with the records
// ZAGlobal.reRenderTableBody = function () {
//     $('._tbody').empty();
//     var tbody = '';

//     if (ZAGlobal.filteredRecords.length === 0) {
//         $('._tbody').html('<tr><td colspan="5">No records available to approve/reject.</td></tr>');
//         return;
//     }

//     ZAGlobal.filteredRecords.forEach(function (record) {
//         tbody += `<tr><td><input type="checkbox" ${record.is_approved || record.is_rejected ? 'disabled' : ''} data-id="${record.entity.id}" data-module="${record.module}"></td><td>${record.entity.name}</td><td>${record.rule.name}</td><td>${record.entity.id}</td><td><div class="_status ${record.is_approved ? '_approved' : record.is_rejected ? '_rejected' : '_'}"></div></td></tr>`;
//     });
//     $('._tbody').append(tbody);
// }

// // Close the popup when the close button is clicked
// close_PopupBtn.addEventListener('click', () => {
//     search_popup.style.display = 'none';
// });

// ZAGlobal.buttonAction = function (action) {
//     var approvedRecordsCount = 0, rejectedRecordsCount = 0;
//     var checkedRecords = $('tbody input[type="checkbox"]:checked').length;

//     if (checkedRecords === 0) {
//         alert('Please select at least one record to approve/reject.');
//         return;  // Exit the function if no checkboxes are selected
//     }

//     if (action === 'reject') {
//         const comments = $('._comments').val() || $('._comments').text();  // Use .val() for input elements or .text() for div/span
//         if (!comments || comments.trim() === '') {
//             alert('Please provide the reason for rejecting.');
//             return;
//         }
//     }


//     $('tbody input[type="checkbox"]:checked').each(function (index, ele) {
//         var config = {
//             Entity: $(ele).data('module'),
//             RecordID: $(ele).data('id'),
//             actionType: action
//         };

//         if (action === 'reject') {
//             const comments = $('._comments').val() || $('._comments').text().trim();  // Correctly capture the comment
//             config.comments = comments; // Ensure trimmed comment is passed
//         }

//         ZOHO.CRM.API.approveRecord(config).then(function (data) {
//             var approvedRecords = [];
//             for (let rec of ZAGlobal.filteredRecords) {
//                 if (rec.entity.id === data.details.id) {
//                     if (action === 'approve') {
//                         rec.is_approved = true;
//                         approvedRecordsCount += 1;
//                     } else if (action === 'reject') {
//                         rec.is_rejected = true;
//                         rejectedRecordsCount += 1;
//                     }
//                 }
//                 approvedRecords.push(rec);
//             }
//             ZAGlobal.filteredRecords = approvedRecords;
//         }).catch(function (error) {
//             // Handle any errors
//             console.log('Error processing record:', error);
//         });
//     });
//     var intervalId = setInterval(function () {
//         if (checkedRecords === (approvedRecordsCount + rejectedRecordsCount)) {
//             ZAGlobal.reRenderTableBody();
//             ZAGlobal.triggerAppRejToast(action, approvedRecordsCount, rejectedRecordsCount);
//             clearInterval(intervalId);
//         }
//     }, 100);
//     action === 'approve' ? console.log('approved') : console.log('rejected');
// }

// ZAGlobal.triggerAppRejToast = function (action, approvedRecordsCount, rejectedRecordsCount) {
//     Toastify({
//         text: `${action === 'approve' ? approvedRecordsCount : rejectedRecordsCount} records were ${action === 'approve' ? 'approved' : 'rejected'}`,
//         duration: 3000,
//         gravity: "top", // `top` or `bottom`
//         position: "center", // `left`, `center` or `right`
//         stopOnFocus: true, // Prevents dismissing of toast on hover
//         onClick: function () { } // Callback after click
//     }).showToast();
// }

// // Ensure the 'select all' checkbox is correctly selecting all checkboxes
// document.addEventListener('DOMContentLoaded', () => {
//     const headerCheckbox = document.querySelector('thead input[type="checkbox"]');
//     const rowCheckboxes = document.querySelectorAll('tbody input[type="checkbox"]');

//     headerCheckbox.addEventListener('change', () => {
//         rowCheckboxes.forEach(checkbox => {
//             checkbox.checked = headerCheckbox.checked;
//         });
//     });
// });

// document.getElementById('searchBar').addEventListener('input', function() {
//     const searchValue = this.value.toLowerCase(); // Get the value from the search bar
//     const rows = document.querySelectorAll('tbody tr'); // Get all rows in the table body

//     rows.forEach(function(row) {
//         const columns = row.querySelectorAll('td'); // Get all columns in the row
//         let matchFound = false;

//         columns.forEach(function(column) {
//             if (column.textContent.toLowerCase().includes(searchValue)) {
//                 matchFound = true;
//             }
//         });

//         if (matchFound) {
//             row.style.display = '';  
//         } else {
//             row.style.display = 'none'; 
//         }
//     });
// });


// ZOHO.embeddedApp.init();

var ZAGlobal = {
    selectedRecords: [], // Store selected record IDs
    allRecords: [],
    filteredRecords: [],
    reRenderTableBody: function () {
        $('._tbody').empty();
        var tbody = '';

        if (ZAGlobal.filteredRecords.length === 0) {
            $('._tbody').html('<tr><td colspan="5">No records available to approve/reject.</td></tr>');
            return;
        }

        // Render filtered records
        ZAGlobal.filteredRecords.forEach(function (record) {
            tbody += `<tr data-id="${record.entity.id}" data-module="${record.module}">
                        <td><input type="checkbox" data-id="${record.entity.id}" data-module="${record.module}" ${ZAGlobal.selectedRecords.includes(record.entity.id) ? 'checked' : ''}></td>
                        <td>${record.entity.name}</td>
                        <td>${record.rule.name}</td>
                        <td>${record.entity.id}</td>
                        <td><div class="_status ${record.is_approved ? '_approved' : record.is_rejected ? '_rejected' : '_'}"></div></td>
                    </tr>`;
        });
        $('._tbody').append(tbody);

        // After the table, render selected records
        renderSelectedRecords();
    }
};

// Function to render selected records at the bottom of the table with a line
function renderSelectedRecords() {
    const selectedRecordsSection = document.querySelector('.selected-records-section');
    selectedRecordsSection.innerHTML = ''; // Clear previous selected records section

    if (ZAGlobal.selectedRecords.length === 0) {
        selectedRecordsSection.style.display = 'none'; // Hide if no selected records
        return;
    }

    selectedRecordsSection.style.display = 'block'; // Show section for selected records

    var selectedRecordsHTML = '<tr><td colspan="5" class="selected-records-header">Selected Records</td></tr>';

    ZAGlobal.selectedRecords.forEach(function (recordId) {
        const record = ZAGlobal.allRecords.find(r => r.entity.id == recordId);
        if (record) {
            selectedRecordsHTML += `<tr class="selected-record">
                                        <td><input type="checkbox" data-id="${record.entity.id}" data-module="${record.module}" checked disabled></td>
                                        <td>${record.entity.name}</td>
                                        <td>${record.rule.name}</td>
                                        <td>${record.entity.id}</td>
                                        <td><div class="_status ${record.is_approved ? '_approved' : record.is_rejected ? '_rejected' : '_'}"></div></td>
                                    </tr>`;
        }
    });

    selectedRecordsSection.innerHTML = selectedRecordsHTML;
}

// Show the popup when the button is clicked
document.getElementById('searchbtn').addEventListener('click', () => {
    document.getElementById('search_popup').style.display = 'flex';
});

// Close the popup when the close button is clicked
document.getElementById('close_PopupBtn').addEventListener('click', () => {
    document.getElementById('search_popup').style.display = 'none';
});

// Close the popup if the user clicks outside of the popup content
window.addEventListener('click', (event) => {
    if (event.target === document.getElementById('search_popup')) {
        document.getElementById('search_popup').style.display = 'none';
    }
});

// Event listener for the "Done" button
document.getElementById('doneBtn').addEventListener('click', () => {
    const selectedModule = document.getElementById('module').value;
    filterRecordsByModule(selectedModule);  // Filter records based on selected module
    document.getElementById('search_popup').style.display = 'none';  // Close the popup after done
});

// Event listener for the "Cancel" button
document.getElementById('resetTableBtn').addEventListener('click', () => {
    ZAGlobal.filteredRecords = ZAGlobal.allRecords;  // Reset to all records
    ZAGlobal.reRenderTableBody();  // Re-render table with all records
    document.getElementById('search_popup').style.display = 'none';  // Close the popup after cancel
});

ZOHO.embeddedApp.on("PageLoad", function (data) {
    if (data && data.Entity) {
        ZAGlobal.module = data.Entity;
        ZOHO.CRM.API.getApprovalRecords({ type: "awaiting" })
            .then(function (toBeApproved) {
                ZAGlobal.filteredRecords = toBeApproved.data;
                ZAGlobal.allRecords = [...toBeApproved.data];

                ZAGlobal.reRenderTableBody(); // Initial render
            })
            .catch(function (error) {
                console.log('Error fetching records:', error);
            });

        ZOHO.CRM.META.getModules().then(function (data) {
            if (data && Array.isArray(data.modules)) {
                populateModules(data.modules);
            }
        });
    }
});

// Function to populate the module select dropdown
function populateModules(modules) {
    const select = document.getElementById('module');
    select.innerHTML = '<option value="">Search in Specific Module</option>';
    modules.forEach(module => {
        const option = document.createElement('option');
        option.value = module.api_name;
        option.textContent = module.api_name;
        select.appendChild(option);
    });

    // Initialize select2 plugin
    $('#module').select2({ placeholder: "Select a module", allowClear: true });

    // Handle change in module selection
    select.addEventListener('change', function () {
        filterRecordsByModule(select.value);
        reSelectPreviousSelections(select.value);
    });
}

// Function to filter records based on selected module
function filterRecordsByModule(selectedModule) {
    if (selectedModule === "") {
        ZAGlobal.filteredRecords = ZAGlobal.allRecords;
    } else {
        ZAGlobal.filteredRecords = ZAGlobal.allRecords.filter(record => record.module === selectedModule);
    }
    ZAGlobal.reRenderTableBody();
}

// Function to re-select previously selected records after switching modules
function reSelectPreviousSelections(selectedModule) {
    const rowCheckboxes = document.querySelectorAll('tbody input[type="checkbox"]');
    rowCheckboxes.forEach(checkbox => checkbox.checked = false); // Deselect all checkboxes

    // Re-select previously selected records for the new module
    ZAGlobal.selectedRecords.forEach(selectedId => {
        rowCheckboxes.forEach(checkbox => {
            if (checkbox.dataset.id == selectedId && checkbox.dataset.module === selectedModule) {
                checkbox.checked = true;
            }
        });
    });
}

// Event listener for checkbox change (record selection)
document.querySelector('tbody').addEventListener('change', function (event) {
    if (event.target.type === 'checkbox') {
        const recordId = event.target.dataset.id;
        if (event.target.checked) {
            ZAGlobal.selectedRecords.push(recordId);
        } else {
            const index = ZAGlobal.selectedRecords.indexOf(recordId);
            if (index > -1) {
                ZAGlobal.selectedRecords.splice(index, 1);
            }
        }
        ZAGlobal.reRenderTableBody();
    }
});

// Button action for approve/reject
ZAGlobal.buttonAction = function (action) {
    const checkedRecords = ZAGlobal.selectedRecords.length;
    if (checkedRecords === 0) {
        alert('Please select at least one record to approve/reject.');
        return;
    }

    if (action === 'reject') {
        const comments = $('._comments').val() || $('._comments').text();
        if (!comments || comments.trim() === '') {
            alert('Please provide the reason for rejecting.');
            return;
        }
    }

    let approvedRecordsCount = 0;
    let rejectedRecordsCount = 0;

    ZAGlobal.selectedRecords.forEach(function (recordId) {
        const record = ZAGlobal.filteredRecords.find(rec => rec.entity.id == recordId);
        if (record) {
            var config = {
                Entity: record.module,
                RecordID: record.entity.id,
                actionType: action
            };

            if (action === 'reject') {
                const comments = $('._comments').val() || $('._comments').text().trim();
                config.comments = comments;
            }

            ZOHO.CRM.API.approveRecord(config).then(function (data) {
                if (action === 'approve') {
                    record.is_approved = true;
                    approvedRecordsCount++;
                } else if (action === 'reject') {
                    record.is_rejected = true;
                    rejectedRecordsCount++;
                }
            }).catch(function (error) {
                console.log('Error processing record:', error);
            });
        }
    });

    // Update the table after action
    var intervalId = setInterval(function () {
        if (checkedRecords === (approvedRecordsCount + rejectedRecordsCount)) {
            ZAGlobal.reRenderTableBody();
            ZAGlobal.triggerAppRejToast(action, approvedRecordsCount, rejectedRecordsCount);
            clearInterval(intervalId);
        }
    }, 100);
};

// Function to trigger toast notifications for actions
ZAGlobal.triggerAppRejToast = function (action, approvedRecordsCount, rejectedRecordsCount) {
    Toastify({
        text: `${action === 'approve' ? approvedRecordsCount : rejectedRecordsCount} records were ${action === 'approve' ? 'approved' : 'rejected'}`,
        duration: 3000,
        gravity: "top", // top or bottom
        position: "center", // left, center or right
        stopOnFocus: true,
        onClick: function () {}
    }).showToast();
};

// Search functionality to filter the table rows
document.getElementById('searchBar').addEventListener('input', function () {
    const searchValue = this.value.toLowerCase();
    const rows = document.querySelectorAll('tbody tr');

    rows.forEach(function (row) {
        const columns = row.querySelectorAll('td');
        let matchFound = false;

        columns.forEach(function (column) {
            if (column.textContent.toLowerCase().includes(searchValue)) {
                matchFound = true;
            }
        });

        if (matchFound) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

ZAGlobal.selectAll = function () {
    const headerCheckbox = document.querySelector('thead input[type="checkbox"]');
    const rowCheckboxes = document.querySelectorAll('tbody input[type="checkbox"]');

    headerCheckbox.addEventListener('change', () => {
        rowCheckboxes.forEach(checkbox => {
            checkbox.checked = headerCheckbox.checked;
            const recordId = checkbox.dataset.id;
            if (checkbox.checked) {
                if (!ZAGlobal.selectedRecords.includes(recordId)) {
                    ZAGlobal.selectedRecords.push(recordId);
                }
            } else {
                const index = ZAGlobal.selectedRecords.indexOf(recordId);
                if (index > -1) {
                    ZAGlobal.selectedRecords.splice(index, 1);
                }
            }
        });
        ZAGlobal.reRenderTableBody();
    });
};


ZOHO.embeddedApp.init().then(function() {
    ZOHO.CRM.CONFIG.getCurrentUser().then(function(data) {
        var userLanguage = data.users[0].locale;

        if(userLanguage === 'en_US') {
            loadEnglishTranslations();
        } else if(userLanguage === 'zh_CN') {
            loadChineseTranslations();
        } else {
            loadEnglishTranslations();  
        }

    }).catch(function(error) {
        console.error('Error fetching current user:', error);
    });
}).catch(function(error) {
    console.error('Error initializing SDK:', error);
});

function loadEnglishTranslations() {
    console.log("Defualt eng lan");
}

function loadChineseTranslations() {
    console.log("Loading Chinese translations...");
    document.getElementById('searchBar').placeholder = "搜索";
    document.getElementById('searchbtn').innerText = "搜索";
    document.getElementById('resetTableBtn').innerText = "重置";
    document.querySelector('.approve').innerText = "批准";
    document.querySelector('.reject').innerText = "拒绝";
    document.querySelector('._comments').placeholder = "评论";
    document.getElementById('recordNameHeader').innerText = "记录名称";
    document.getElementById('approvalProcessNameHeader').innerText = "审批流程名称";
    document.getElementById('recordIdHeader').innerText = "记录ID";
    document.getElementById('statusHeader').innerText = "状态";
    document.getElementById('doneBtn').innerText = "完毕";
    document.getElementById('cancelBtn').innerText = "取消";
    document.querySelector('.moduleclass').innerHTML = "选择特定模块";
    document.getElementById('popup_header').innerText = "过滤器列表";

}
ZOHO.embeddedApp.init();
